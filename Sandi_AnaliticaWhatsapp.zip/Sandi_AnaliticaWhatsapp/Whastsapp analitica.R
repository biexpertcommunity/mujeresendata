#########################################################################
### -- TEMA: ANAL�TICA PARA WHATSAPP -- ## 
#########################################################################
### Autora: Sandi Barrientos Zamora  ## 
### Data Scientist##  
### Contacto: https://www.linkedin.com/in/sandibarza ##
### Facebook: https://www.facebook.com/DataLadiesPeru ##

# Remover las variables en memoria, limpieza de la memoria
rm(list = ls())

# anular la notacionn cientifica en los graficos
options(scipen=999)

#Carga de las libreias necesarias
library(ggplot2)#graficar
library(lubridate) #transformar fechas
library(reshape2)
library(tm) # Crear corpus
library(SnowballC)
library(wordcloud)
library(wordcloud2)
library(RColorBrewer)
library(stringr)
library(syuzhet)# Procesa el texto e identifica la emoción
library(dplyr) # transformar tablas
library(rwhatsapp) #para extraer o darle forma de tabla al archivo de Whatsapp
library(tidyr) 

## Nos ubicamos en el directorio
setwd("D:/datascience/data ladies/meetup/Mujereres en Data de BI Expert")

## Leemos el archivo exportado de Whatsapp
chat <- rwa_read("Chat.txt", encoding = "UTF-8")
Chat_duplicado <- chat


#Agregamos columna dia (mutate crea nuevas variables a partir de las ya existentes)
chat <- chat %>% mutate(day = date(time))


## AN�LISIS EXPLORATORIO

## Exploramos las primeras filas
head(chat,4)

#Vemos la dimension del chat del grupo
dim(chat)

## Vemos la evolucion en el tiempo del chat, (unlist convierte una lista a vector)
descriptiva <- unlist(chat %>%
                        group_by(day) %>%
                        summarise(mensajes=n()) %>% summarise(min(mensajes),round(mean(mensajes)),max(mensajes)))

chat %>%
  count(day) %>%
  ggplot(aes(x = day, y = n)) +
  geom_bar(stat = "identity", fill="green", alpha=0.8) + 
  ylab("Total mensajes") + xlab("dia") + 
  ggtitle("Mensajes por dia") + 
  geom_hline(yintercept=descriptiva[2]) + 
  geom_smooth(color = 'blue',fill="gray") #La tendencia descrita se muestra en la línea de color azul, mientras que las bandas grises reflejan los intervalos de confianza del ajuste.

## tabla de mensajes por dia 

chat %>%
  mutate(dia_semana = wday(day, label = TRUE)) %>% #wday(retorna el dia de la semana)
  group_by(dia_semana) %>%
  summarise(mensajes=n())

## Graficamos los mensajes por dia 
chat %>%
  mutate(dia_semana = wday(day, label = TRUE)) %>% #wday(retorna el dia de la semana)
  group_by(dia_semana) %>%
  summarise(mensajes=n())%>%
ggplot(aes(x = dia_semana, y = mensajes)) +
  geom_bar(stat = "identity", fill="cyan", alpha=0.8) + 
  ylab("mensajes totales") + xlab("dia") + 
  geom_text(aes(label= mensajes), vjust=-1, hjust=0.5) + 
  ggtitle("Mensajes totales por dia de la semana")


## Graficamos mensajes por autor
chat %>%
  count(author) %>%
  top_n(n = 14, n) %>% #colocar el numero de personas que quieren analizar
  ggplot(aes(x = reorder(author, n), y = n)) + 
  geom_bar(stat = "identity", fill="magenta", alpha=0.8) + 
  ylab("# de mensajes") + xlab( "Autor") + 
  geom_text(aes(label= n), vjust=0, hjust=-0.5) + 
  coord_flip() +
  ggtitle("N° de Mensajes por autor")


## Graficamos el uso por emojies
chat %>%
  unnest(emoji) %>%                                         
    count(emoji, sort = TRUE) %>%  
    top_n(n = 10, n) %>%           
    ggplot(aes(x = reorder(emoji, n), y = n)) + 
    geom_col(show.legend = FALSE, fill="orange", alpha=0.9) + 
    ylab("Cantidad") + xlab( "Emoji") +
    coord_flip() +
    geom_text(aes(label= n), vjust=0, hjust=-0.05) +
    ggtitle("Cantidad de veces de emoji")

chat %>%
  unnest(emoji_name) %>%                 # Se extraen los nombres de los emojies
  count(emoji_name, sort = TRUE) %>%  
  top_n(n = 10, n) %>%           
  ggplot(aes(x = reorder(emoji_name, n), y = n)) + 
  geom_col(show.legend = FALSE, fill="orange", alpha=0.5) + 
  ylab("Cantidad") + xlab( "Nombre del emoji") +
  coord_flip() +
  ggtitle("Cantidad de veces de emoji")

## Graficamos la cantidad enviada de multimedias por videos, audio, stikers, etc…
chat %>%
  filter (text=="<Multimedia omitido>") %>%    
  count(author) %>%  
  top_n(n = 10, n) %>%          
  ggplot(aes(x = reorder(author, n), y = n)) + 
  geom_bar(stat = "identity", fill="blue", alpha=0.7) + 
  ylab("Cantidad") + xlab( "Autor") +
  coord_flip() +
  geom_text(aes(label= n), vjust=0, hjust=-0.05) +
  ggtitle("Frecuencia de uso de objeto multimedia")

########################################## Analitica del Texto
#### Creamos el cuerpo del texto a analizar 
chat1 <- rwa_read("Chat.txt", encoding = "UTF-8")
chat1 <- chat1 %>% select(text)
docs <- Corpus(VectorSource(chat1)) #convierte en cuerpo textual

###LIMPIEZA:

# lleva a minúsculas
d  <- tm_map(docs, tolower)
# quita espacios en blanco
d  <- tm_map(d, stripWhitespace)
# quita la puntuación
d <- tm_map(d, removePunctuation)
# quita los números
d <- tm_map(d, removeNumbers)

#stopwords("spanish")*
stopwords <- read.table(file="stop_words_spanish.txt",header = TRUE,encoding="UTF-8")

d <- tm_map(d, removeWords, stopwords("spanish"))
d <- tm_map(d, removeWords, c("multimedia","omitido","ufd","ufdufdufd","ufc","ufufuf"))

### Creamos la matrix de terminos
dtm <- TermDocumentMatrix(d)
mat <- as.matrix(dtm)
v <- sort(rowSums(mat),decreasing=TRUE)

#Creamos el Data frame
data <- data.frame(word = names(v),freq=v) 
head(data, 100)

#genera la wordcloud
set.seed(245)

wordcloud2(data, size = 1.6)
wordcloud2(data, size = 1.6, color='random-light', backgroundColor="black")
#wordcloud2(data, size = 1.6, shape = 'triangle') ##otras formas: circle, cardioid,diamond,triangle-forward,triangle,pentagon,star

#Obtener sentimiento del texto
Sentiment <- get_nrc_sentiment(chat$text, language = "spanish")
head(Sentiment)
tail(Sentiment)
text <- cbind(chat,Sentiment)

#contamos el sentimiento por categoria
TotalSentiment <- data.frame(colSums(text[,c(9:18)]))
names(TotalSentiment) <- "count"
TotalSentiment <- cbind("sentiment" = rownames(TotalSentiment), TotalSentiment)
rownames(TotalSentiment) <- NULL
TotalSentiment [order(TotalSentiment$count, decreasing= TRUE),]

#total sentiment positivos y negativos *
TotalSentiment$sentiment =with(TotalSentiment, reorder(sentiment,count))

ggplot(data = TotalSentiment[9:10,], aes(x = sentiment, y = count)) +
  geom_bar(aes(fill = sentiment), stat = "identity") +
  geom_text(aes(label= count), vjust=0, hjust=-0.05) +
  theme(legend.position = "none") +
  xlab("") + ylab("Total conteo") + ggtitle("Sentimientos identificados en conversaciones del Grupo")


#total Emociones identificadas *
ggplot(data = TotalSentiment[1:8,], aes(x = sentiment, y = count)) +
  geom_bar(aes(fill = sentiment), stat = "identity") +
  geom_text(aes(label= count), vjust=0, hjust=-0.05) +
  theme(legend.position = "none") +
  coord_flip() +
  xlab("") + ylab("Total conteo") + ggtitle("Emociones identificadas en conversaciones del Grupo")


#Palabras mas usadas *
data[1:8, ] %>%
  arrange(freq) %>%
  mutate(word=factor(word, levels =word)) %>%
  ggplot( aes(x=word, y=freq)) +
  geom_segment( aes(xend=word, yend=0)) +
  geom_point( size=6, color="orange") +
  coord_flip() +
  theme_bw() +
  xlab("") +
  labs(title = "Palabras mas frecuentes en los chats del Grupo", x = "Palabras", y = "Numero de usos")



