#######################################
#Visualizacion de datos con ggplot2   #
#Estephani Rivera Jaramillo           #
#correo: estephani.rivera.j@gmail.com #
#######################################

install.packages("ggplot2")
install.packages("tibble")
install.packages("dplyr")
install.packages("Lock5Data")

library(ggplot2)
library(tibble)#Crea un marco de datos o una lista y algunos otros comandos �tiles
library(dplyr)
library(Lock5Data)#Un paquete de conjunto de datos integrado en R
library(gridExtra)

setwd("D:/Capacitaciones de Estephani Rivera/Visualizacion de datos con gglot2")

#lectura de archivo
df_hum <- read.csv("humidity.csv")

#colnames(df_hum)
#str(df_hum)

data()

#Investigaci�n de datos y variables
str(mtcars)#Pruebas en carretera de autom�viles de Motor Trend
str(airquality)#Mediciones de la calidad del aire de Nueva York
str(rock)#Mediciones en muestras de roca de petr�leo
str(sleep)#Datos de sue�o del estudiante
#trazado con qplot y R

hist(airquality$Temp)
qplot(airquality$Temp)

#Carga los datos de humedad y descripci�n del clima
df_hum <- read.csv("humidity.csv")
df_desc <- read.csv("weather_description.csv")
df_t <- read.csv("temperature.csv")
str(df_hum)
str(df_desc)

#Ejemplo1
#Ejercicio: crear un histograma usando qplot y ggplot##########################
hist(df_hum$Vancouver)
qplot(df_hum$Vancouver)
ggplot(df_hum,aes(x=Vancouver))#es sin�nimo de est�tica, o las cantidades que consiguen traza en el x- e y- ejes, y sus cualidades.
ggplot (df_hum, aes(x=Vancouver)) + geom_histogram() #el histograma con ggplot

#histograma para dos ciudades.
ggplot(df_t,aes(x=Vancouver))+geom_histogram()#La temperatura m�xima de Vancouver es de alrededor de 280�C.
ggplot(df_t,aes(x=Miami))+geom_histogram()#La temperatura m�xima de Miami es de alrededor de 300

#Crear gr�ficos de barras

glimpse(df_desc)
ggplot(df_desc,aes(x=Vancouver)) + geom_bar()
#Vancouver tiene un clima despejado, en su mayor parte. 
#Los per�odos de nieve son mucho menos frecuentes.

ggplot(df_desc,aes(x=Seattle)) + geom_bar() 
#Seattle ve una mayor cantidad de lluvia.

require (Lock5Data)
glimpse(RetailSales)

#Ejercicio: crea un gr�fico de barras 2D######################
ggplot(RetailSales,aes(x=Month,y=Sales)) + geom_bar(stat="identity")
#Note: months are not ordered.
#Order the months:
#Check levels
levels(RetailSales$Month)
#Check if it has NA vaues
is.na(RetailSales)
#It has NA values so remove them and create a new data set
MyRetailSales <- na.omit(RetailSales)
#Reorder the months
MyRetailSales$Month <-factor(MyRetailSales$Month, 
                             levels = c("Jan", "Feb", "Mar", "Apr", "May", "Jun",
                                        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"))
#Plot
ggplot(MyRetailSales,aes(x=Month,y=Sales)) + geom_bar(stat="identity")


#An�lisis y creaci�n de diagramas de caja##############################################
#Subtopic: Crea un diagrama de caja
# Obtenga los meses de la variable datetime y cree una columna de mes.
df_hum$datetime <- as.character(df_hum$datetime)
df_hum$month <- substr(df_hum$datetime,6,7)

#Display
ggplot(df_hum,aes(x=month,y=Vancouver)) + geom_boxplot()
ggplot(df_hum,aes(x=month,y=Seattle)) + geom_boxplot()
ggplot(df_hum,aes(x=month,y=San.Francisco)) + geom_boxplot()

#Gr�fico de dispersi�n#################################################################
a = 3.4
v0 = 27
#Genere algunos n�meros de tiempo aleatorios
time <- runif(50, min=0, max=200)
distance <- sapply(time, function(x) v0*x + 0.5*a*x^2)
df <- data.frame(time,distance)
ggplot(df,aes(x=time,y=distance)) + geom_point()
#Podemos ver una correlaci�n positiva, lo que significa que a medida que aumenta el tiempo, aumenta la distancia.

######La gram�tica de los gr�ficos#######
#diferencias entre los histogramas no agrupados y agrupados.
ggplot(df_hum,aes(x=Vancouver))+geom_histogram()+ggtitle("Default Binning")
ggplot(df_hum,aes(x=Vancouver))+geom_histogram(bins=15)+ggtitle("Rebinned")
#La elecci�n de un tipo diferente de agrupamiento puede hacer que la distribuci�n sea m�s continua, y luego se puede comprender mejor la forma de la distribuci�n

#Mejorar la trama modificando los valores predeterminados
ggplot(df_hum,aes(x=Vancouver))+
  geom_histogram(bins=15,fill="white",color=1)+
  ggtitle("Humidity for Vancouver city")+
  xlab("Humidity")+
  theme(axis.text.x=element_text(size = 12),
        axis.text.y=element_text(size=12))

#Ejercicio: crea un diagrama de caja mejorado
ggplot(df_hum,aes(x=month,y=Vancouver)) + 
  geom_boxplot(color=1,fill=3) + 
  ylab("Humidity")+ 
  theme(axis.text.y=element_text(size=15),
        axis.text.x=element_text(size = 15),
        axis.title.x=element_text(size=15,color=2),
        axis.title.y=element_text(size=15,color=2))




#Ejemplo2
################################################################################################
library("ggplot2")
library("tibble")
library("gridExtra")
library("dplyr")
library("Lock5Data")

#lectura de data
df <- read.csv("gapminder-data.csv")
df2 <- read.csv("xAPI-Edu-Data.csv")
df3 <- read.csv("LoanStats.csv")

str(df)
str(df2)
str(df3)



#Aplicar gram�tica de gr�ficos para crear una visualizaci�n compleja

#Subtopic - Layers
p1 <- ggplot(df,aes(x=Electricity_consumption_per_capita))
p2 <- p1+geom_histogram()
p3 <- p1+geom_histogram(bins=15)
p3

#Exercise-Layers
p4 <- p3+xlab("Electricity consumption per capita")
p4

#Exercise- Scales
p1 <- ggplot(df,aes(x=gdp_per_capita))
p2 <- p1+geom_histogram()
p2
#Where does the maximum occur? We need to have a finer labelling to answer
#the question
p2 + scale_x_continuous(breaks=seq(0,40000,4000) )


#Generate some random time numbers
t <- seq(0, 360, by=15)
r <- 2
qplot(r,t)
qplot(r,t)+coord_polar(theta="y")
qplot(r,t)+coord_polar(theta="y")+scale_y_continuous(breaks=seq(0,360,30))


#Faceta
#Ejercicio: usar facetas para dividir datos

p <- ggplot(df, aes(x=gdp_per_capita, y=Electricity_consumption_per_capita)) + 
  geom_point()
p + facet_grid(Country ~ .) #Horizontally Arranged
p + facet_grid(. ~ Country) #Vertically Arranged
p + facet_wrap(~Country)

#Componentes visuales - Color y forma diferenciados
#Uso y cambio de estilos y colores
#usar colores en gr�ficos


#Usar color para agrupar puntos por variable
dfs <- subset(df,Country %in% c("Germany","India","China","United States"))
var1<-"Electricity_consumption_per_capita"
var2<-"gdp_per_capita"
name1<- "Electricity/capita"
name2<- "GDP/capita"
#Cambiar el color y la forma de los puntos.
p1<- ggplot(df,aes_string(x=var1,y=var2))+
  geom_point(color=2,shape=2)+xlim(0,10000)+xlab(name1)+ylab(name2)
#Agrupar puntos por una variable asignada al color y la forma
p2 <- ggplot(dfs,aes_string(x=var1,y=var2))+
  geom_point(aes(color=Country,shape=Country))+xlim(0,10000)+xlab(name1)+ylab(name2)
grid.arrange(p1, p2, nrow = 2)

#Boxplot - color diferenciado.
ggplot (df2, aes (x = GradeID, y = VisitedResources)) + geom_boxplot (aes (fill = Class))

#color diferenciar con calificaci�n crediticia.
dfn <- df3[,c("home_ownership","loan_amnt","grade")]
dfn <- na.omit(dfn)
dfn <- subset(dfn, !dfn$home_ownership %in% c("NONE"))
ggplot(dfn,aes(x=home_ownership,y=loan_amnt))+geom_boxplot(aes(fill=grade))


#Ejemplo3
##########################################################################################





